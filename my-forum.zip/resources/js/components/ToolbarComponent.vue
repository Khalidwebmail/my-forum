<template>
    <v-toolbar>
        <v-app-bar-nav-icon></v-app-bar-nav-icon>
        <v-app-bar-title>SPA Blog</v-app-bar-title>
        <v-spacer></v-spacer>
        <v-toolbar-items class="hidden-sm-and-down">

            <router-link v-for="item in items" :key="item.title" :to="item.to" v-if="item.show">
                <v-btn text>{{item.title}}</v-btn>
            </router-link>
        </v-toolbar-items>
    </v-toolbar>
</template>

<script>
export default {
    name: "ToolbarComponent",
    data(){
        return {
            items: [
                {'title': 'Forum', to: '/forum', show: true},
                {'title': 'Signin', to: '/login', show: !User.loggedIn()},
                {'title': 'Signup', to: '/signup', show: !User.loggedIn()},
                {'title': 'Category', to: '/category', show: User.loggedIn()},
                {'title': 'Ask Question', to: '/ask-question', show: User.loggedIn()},
                {'title': 'Logout', to: '/logout', show: User.loggedIn()},
            ]
        }
    },
    created() {
        EventBus.$on('logout', () => {
            User.logout()
        })
    }
}
</script>

<style scoped>

</style>
